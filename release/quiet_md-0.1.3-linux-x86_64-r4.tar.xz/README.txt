quiet.md 0.1.3 (Linux x86_64)

1. 解压后运行 ./quiet_md（需要 X11 / Wayland 图形环境）。
2. 首次启动会在用户文档目录创建 Quiet.md 笔记库。
3. 导出 PDF 需要系统里有 Chromium / Chrome / Edge 任一浏览器（可用 QUIET_MD_BROWSER 指定路径）。
4. 设置 → 同步：FTP/FTPS、SFTP、SMB、S3 各自独立配置，可同时启用多个，同步时依次同步所有已启用协议；连接信息保存在笔记库的 sync.json。
5. 密码 / Secret Key 默认掩码显示，点“显示 / 隐藏”临时查看。
6. 导入支持 Markdown / XML 及 txt、log、csv、sql 等纯文本（原样保留为代码块）。
7. 本构建动态链接 libssl.so.3（OpenSSL 3），用于 FTP/S3 的 TLS。