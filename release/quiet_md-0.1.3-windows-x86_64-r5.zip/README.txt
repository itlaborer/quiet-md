quiet.md 0.1.3 (Windows x86_64)

1. 解压到任意目录，双击 quiet_md.exe 运行。
2. 若 SmartScreen 提示“未知发布者”，选择“仍要运行”（未做代码签名）。
3. 首次启动会在用户文档目录创建 Quiet.md 笔记库。
4. 导出 PDF 使用系统自带的 WebView/浏览器能力，无需额外安装。
5. 设置 → 同步：FTP/FTPS、SFTP、SMB、S3 各自独立配置，可同时启用多个，同步时依次同步所有已启用协议；连接信息保存在笔记库的 sync.json。
6. 密码 / Secret Key 默认掩码显示，点“显示 / 隐藏”临时查看。
7. 导入支持 Markdown / XML 及 txt、log、csv、sql 等纯文本（原样保留为代码块）。
8. 设置 → 发布：可将当前笔记发布到 GitHub 仓库、微信公众号草稿、今日头条 / 百家号等平台，配置保存在笔记库的 publish.json。
